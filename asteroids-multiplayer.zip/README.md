# Asteroids Multiplayer

Un juego de asteroides multijugador implementado con Node.js, Socket.IO y HTML5 Canvas.

## Instalación

1. Instalar dependencias:
   ```bash
   npm install
   ```

2. Iniciar el servidor:
   ```bash
   npm start
   ```

3. Abrir en el navegador:
   http://localhost:3000

## Controles
- Flechas: Mover la nave
- Espacio: Disparar
